---
name: antigravity
description: "Antigravity-specific operational guidance for the academic research workspace. Standardizes the use of task boundaries, artifacts, and agentic modes."
---

# Antigravity — Workspace Operational Excellence

This skill defines how Antigravity should operate within the Thesis workspace to ensure maximum transparency, rigor, and user alignment.

## Core Protocols

### 1. Task Management (`task.md`)
- **ALWAYS** initialize a `task.md` artifact at the start of any complex operation (e.g., "Write a paper", "Perform deep research").
- Breakdown tasks into granular sub-steps corresponding to the research phases.
- Update `task.md` concurrently with `task_boundary` calls.

### 2. Artifact Management
- Use artifacts for ALL persistent research outputs:
  - `implementation_plan.md` for planning large-scale writing or research tasks.
  - Research briefs, literature matrices, and outlines.
  - Full paper drafts and reviewer reports.
  - `walkthrough.md` for final verification and handoff.
- All artifacts should be stored in the conversation's brain directory.

### 3. Agentic Modes
- **PLANNING**: Use for defining research questions, methodology, and paper structures. Require user approval via `notify_user` before proceeding.
- **EXECUTION**: Use for drafting, data analysis, and literature synthesis.
- **VERIFICATION**: Use for citation checking, formatting audits, and peer review simulation.

### 4. Visual Tools
- Use `generate_image` to create conceptual diagrams or placeholder figures for papers.
- Use `browser` tools for searching recent academic databases (Google Scholar, arXiv) when internal tools are insufficient.

## Integration Guidelines

### With `deep-research`
- Each research phase (Scoping, Investigation, Analysis) should be marked by a `task_boundary` update.
- The "RQ Brief" and "Methodology Blueprint" should be presented as artifacts for review.

### With `academic-paper`
- The "Paper Configuration Record" should be an artifact.
- Section-by-section drafting progress should be reflected in the `task_status`.
- Final outputs (LaTeX, PDF) should be verified through the `VERIFICATION` mode.

## Quality Standards
- **Conciseness**: Follow the "AS CONCISE AS POSSIBLE" rule for user-facing artifacts.
- **Transparency**: Never move to a new research phase without updating the user on progress.
- **Rigor**: Use Antigravity's self-correction capabilities to audit citations and logical flow.
